function Continue(variables){
    console.log("Continue place-holder")
}
function checksuplies(variables){
    console.log("Food: "+variables.suplies.food+"kg")
    console.log("Water: "+variables.suplies.water+"L")
    console.log("Waste Water: "+variables.suplies.wastewater+"L")
    console.log("Oxygen: "+variables.suplies.oxygen+"L")
    console.log("CO2: "+variables.suplies.carbono2+"L")
    console.log("Fuel: "+variables.suplies.fuel+"L")
    console.log("Spair solar pannels: "+variables.suplies.spareparts.solarpannel)
    console.log("Spair water filters: "+variables.suplies.spareparts.waterfiltration)
    console.log("Spair air filtrers: "+variables.suplies.spareparts.oxygenfiltration)
}
function changefoodrations(variables){
    console.log("changefoodrations place-holder")
}
function lookforpeople(variables){
    console.log("look for people place-holder")
}
function checkcondition(variables){
    console.log("checkcondition place-holder")
}
function checkweather(variables){
    console.log("checkweather place-holder")
}
//function lookatmap(variables){console.log("Map isnt made yet?")}

function daymenu(variables){
    console.log("Day: "+variables.basic.timespent)
    console.log("1. Continue")
    console.log("2. Check suplies")
    console.log("3. change food rations")
    console.log("4. look for other ships")
    console.log("5. check ship condition")
    console.log("6. check ship path")
    choice123(variables)
    if (variables.choosing.choice == 1){
        Continue(variables)
    }else if (variables.choosing.choice == 2){
        checksuplies(variables)
    }else if (variables.choosing.choice == 3){
        changefoodrations(variables)
    }else if (variables.choosing.choice == 4){
        lookforpeople(variables)
    }else if (variables.choosing.choice == 5){
        checkcondition(variables)
    }else if (variables.choosing.choice == 6){
        checkweather(variables)
    }else{
        daymenu(variables)
    }
    
}

function meteorhit(variables, Lv){
    console.log("Meteorhit placeholder")
    console.log("Meteor cloud severity: "+Lv)
}


function passday(variables){
    setInterval(() => {
        variables.days.meteor.push((Math.floor(Math.random() * 200))+1)
    variables.suplies.food -= variables.usage.foodrations
    variables.suplies.water -= variables.usage.waterrations
    variables.suplies.wastewater += variables.usage.waterrations
    variables.suplies.wastewater -= variables.usage.waterspeed
    variables.suplies.water += (variables.usage.waterspeed * variables.usage.waterefficiency)
    variables.suplies.carbono2 -= variables.usage.oxygenspeed
    variables.suplies.oxygen += (variables.usage.oxygenspeed * variables.usage.oxygenefficiency)
    if (variables.days.meteor[0] >= 190){
        variables.basic.hold = (variables.days.meteor[0] - 190)
        meteorhit(variables, variables.basic.hold)
    }
    variables.days.meteor.shift()
    variables.basic.days += 1
    variables.basic.daysleft -= 1
    console.log("Day: "+variables.basic.days)
    }, 3000);
    
}