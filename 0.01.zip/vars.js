console.log("vars.js loaded")

var variables = {
    suplies : {
        food: 938,
        water: 584,
        wastewater: 0,
        oxygen: 100000,
        carbono2: 0,
        fuel: 0,
        spareparts : {
            solarpannel: 0,
            waterfiltration: 0,
            oxygenfiltration: 0
        },
        parts : {
            waterfilter : 0,
            airscruber : 0,
        }

    },
    basic : {
        daysleft: 1000,
        health: 0,
        days : 0,
        hold : 0
    },
    counts : {
        accept:0,
        speed:10,
        choose:true
    },
    names : {
        playermain : "Playermain",
        player1 : "Player1",
        player2 : "Player2",
        player3 : "Player3",
        player4 : "Player4",
        player5 : "Player5"
    },
    costs : {
        money : 1000,
        food : 100,
        water : 0.1,
        fuel : 3,
        spairparts:{
            solars : 150,
            waterfilter : 150,
            airscruber : 150 
        }
    },
    choosing : {
        choice : 0,
        choiceyn : true,
        choiceplace : "y",
        choices : ["y", "n", "yes", "no"],
    },
    usage : {
        foodration : 1,
        waterration : 550,
        waterefficiency : 0.9,
        oxygenefficiency : 0.8,
        waterspeed : 20,
        oxygenspeed : 30000
    },
    days : {
        meteor : []
    }
}


console.log(variables)
