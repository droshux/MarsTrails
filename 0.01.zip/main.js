console.log("Main.js loaded")
var y = 100;
var x = 0
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
passday(variables)